



/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "keypad.h"
#include <stdio.h>
#include <math.h>
#define PI 3.14

int N=100;
float signal[100];
uint16_t i = 0;
uint8_t value;

CY_ISR (ISR_Timer_DAC_Handler){
    value= 128 + 128*signal[i];
    DAC_SetValue(value);
    i++;
    if (i==N){i=0;}
    Timer_DAC_ISR_ReadStatusRegister();
}

float x,y=0;
char b[100]={'\0'};
float s[100];



int dac(void)
{
    
    uint16_t cnt = 0;
    
    for(int j=0; j<N; j++){
        signal[j]=sin(2*PI*j/N);
    }
    
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    CyGlobalIntEnable;  /* Enable global interrupts. */
    LCD_Char_ClearDisplay();
    ADC_Start();
    ADC_StartConvert();
    DAC_Start();
    DAC_SetValue(0);
    ISR_Timer_DAC_StartEx(ISR_Timer_DAC_Handler);
    Timer_Start();
    Timer_DAC_Start();
    LED4_Write(1);
    
      
    for(;;){  
    
      
    if(0x80 & Timer_ReadStatusRegister()){
        if (cnt < 1000){
            cnt++;
        }
        else{
            LED1_Write(!LED1_Read());
            cnt=0;
        }
    }
    
    if(0x80 & Timer_ReadStatusRegister()){
        value=128+128*signal[i];
        DAC_SetValue(value);
        i++;
        if (i==N){i=0;}
        Timer_DAC_ReadStatusRegister();
    }
    
    
        
        
    
}}
/* [] END OF FILE */
