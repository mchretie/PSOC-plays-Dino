/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "keypad.h"
#include <stdio.h>
#include <math.h>
#define PI 3.14


float jmp;
uint16_t i = 0;
uint8_t value;
uint16 ms_count;
int score= 0 ;

CY_ISR(MY_ISR) {
    ms_count++;
     
    if(ms_count == 1000) { // 1 second
        score+=10;
        LCD_Char_Position(1,0);
        LCD_Char_PrintNumber(score);
        ms_count = 0;// reset ms counter
        
    }
}

CY_ISR (ISR_Timer_DAC_Handler){
    value= 128 + 128*jmp;
    DAC_SetValue(value);
    Timer_DAC_ISR_ReadStatusRegister();
}
void duck(){

LED3_Write(1);
LED4_Write(1);
DUCK_WriteCompare(1100);
CyDelay(250);
DUCK_WriteCompare(500);
LCD_Char_Position(0,0);  
LCD_Char_PrintString("Duck ");
LED3_Write(0);
DAC_SetValue(100);
LED4_Write(0);}

void jump(){

LED1_Write(1);
LED2_Write(1);
JUMP_WriteCompare(1100);
CyDelay(250);
JUMP_WriteCompare(500);
DAC_SetValue(200);
LCD_Char_Position(0,0); 
LCD_Char_PrintString("Jump ");
LED1_Write(0);
LED2_Write(0);}

float x,y=0;
char b[100]={'\0'};
float s[100];



int main(void)
{
     /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    ADC_Start();
    LCD_Char_Start();
    LCD_Char_ClearDisplay();
    CyGlobalIntEnable;
    JUMP_Start();
    DUCK_Start();
    LCD_Char_Init();
    LCD_Char_Start();
    LCD_Char_PrintString("READY");
    keypadInit();
    DAC_Start();
    DAC_SetValue(0);
    float32 temp;
    char key;
   

    for(;;)
    {
    key=keypadScan();
    if (SW3_Read()){
    Timer_Stop();
    score=0;
    LCD_Char_ClearDisplay();
    LCD_Char_Position(0,0);
    LCD_Char_PrintString("READY");}    
    ADC_StartConvert();
    ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
    x=ADC_GetResult32();
    temp=y;
    jmp=0;
    float32 y =ADC_CountsTo_mVolts(x);
     if (SW1_Read() || (y<1300 ) || key=='2'){
        jump();
        if ( score == 0 ){
            Timer_Start(); // Configure and enable timer
            isr_1_StartEx(MY_ISR);}}    
    if ( SW2_Read()  || key=='5') {
            duck();
            if ( score == 0 ){
            Timer_Start(); // Configure and enable timer
            isr_1_StartEx(MY_ISR);}
            }
          
   if(0x80 & Timer_ReadStatusRegister()){
        value=128+128*jmp;
        DAC_SetValue(value);
        i++;
        Timer_DAC_ReadStatusRegister();
    }
    CyDelay(75);
   
    

      
      
      
      
    
    
        
        
    
}}
/* [] END OF FILE */
